package com.bouncer77.CourseProgressMaestro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseProgressMaestroApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourseProgressMaestroApplication.class, args);
	}

}
