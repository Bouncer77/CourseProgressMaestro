package com.bouncer77.CourseProgressMaestro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseProgressMaestroApplicationTests {

	@Test
	void contextLoads() {
	}

}
